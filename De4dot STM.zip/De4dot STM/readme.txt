De4dot mod, build by CatBui (aka NgonNguyen, aka computerline) and HTC - VinCSS
Addition support for:
1. ConfuserEx:  18/08/2020
